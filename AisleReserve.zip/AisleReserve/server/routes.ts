import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertInquirySchema } from "@shared/schema";
import { sendEmail, generateInquiryEmail } from "./services/emailService";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertInquirySchema.parse(req.body);
      
      // Store inquiry
      const inquiry = await storage.createInquiry(validatedData);
      
      // Send email notification
      const emailContent = generateInquiryEmail(inquiry);
      const emailSent = await sendEmail({
        to: process.env.CONTACT_EMAIL || "hello@elegancemanor.com",
        from: process.env.FROM_EMAIL || "noreply@elegancemanor.com",
        subject: emailContent.subject,
        html: emailContent.html,
        text: emailContent.text
      });

      if (emailSent) {
        res.json({ 
          success: true, 
          message: "Thank you for your inquiry! We'll contact you within 24 hours.",
          inquiryId: inquiry.id
        });
      } else {
        res.json({ 
          success: true, 
          message: "Your inquiry has been received. We'll contact you within 24 hours.",
          inquiryId: inquiry.id,
          note: "Email notification pending"
        });
      }
    } catch (error) {
      console.error("Contact form error:", error);
      res.status(400).json({ 
        success: false, 
        message: "Please check your form data and try again." 
      });
    }
  });

  // Get inquiries (for admin use)
  app.get("/api/inquiries", async (req, res) => {
    try {
      const inquiries = await storage.getInquiries();
      res.json(inquiries);
    } catch (error) {
      console.error("Get inquiries error:", error);
      res.status(500).json({ message: "Failed to retrieve inquiries" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
