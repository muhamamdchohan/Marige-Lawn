import { MailService } from '@sendgrid/mail';

if (!process.env.SENDGRID_API_KEY) {
  console.warn("SENDGRID_API_KEY environment variable not set - email functionality will be disabled");
}

const mailService = new MailService();
if (process.env.SENDGRID_API_KEY) {
  mailService.setApiKey(process.env.SENDGRID_API_KEY);
}

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  if (!process.env.SENDGRID_API_KEY) {
    console.log('Email would be sent:', params);
    return true; // Return true for development
  }

  try {
    await mailService.send({
      to: params.to,
      from: params.from,
      subject: params.subject,
      text: params.text,
      html: params.html || '',
    });
    return true;
  } catch (error) {
    console.error('SendGrid email error:', error);
    return false;
  }
}

export function generateInquiryEmail(inquiry: any) {
  const services = inquiry.services ? JSON.parse(inquiry.services) : {};
  const servicesList = Object.entries(services)
    .filter(([_, value]) => value)
    .map(([key, _]) => key.charAt(0).toUpperCase() + key.slice(1))
    .join(', ');

  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #D4AF37;">New Wedding Inquiry - Elegance Manor</h2>
      
      <div style="background: #f9f9f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="color: #8B4B6B; margin-top: 0;">Couple Information</h3>
        <p><strong>Bride:</strong> ${inquiry.brideName}</p>
        <p><strong>Groom:</strong> ${inquiry.groomName}</p>
        <p><strong>Email:</strong> ${inquiry.email}</p>
        <p><strong>Phone:</strong> ${inquiry.phone}</p>
      </div>

      <div style="background: #f9f9f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="color: #8B4B6B; margin-top: 0;">Event Details</h3>
        <p><strong>Wedding Date:</strong> ${inquiry.weddingDate || 'Not specified'}</p>
        <p><strong>Guest Count:</strong> ${inquiry.guestCount || 'Not specified'}</p>
        <p><strong>Preferred Venue:</strong> ${inquiry.preferredVenue || 'Not specified'}</p>
        <p><strong>Services Interested In:</strong> ${servicesList || 'None specified'}</p>
      </div>

      ${inquiry.message ? `
      <div style="background: #f9f9f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="color: #8B4B6B; margin-top: 0;">Special Requests</h3>
        <p>${inquiry.message}</p>
      </div>
      ` : ''}

      <p style="color: #666; font-size: 14px; margin-top: 30px;">
        This inquiry was submitted through the Elegance Manor website.
        Please respond within 24 hours to maintain our excellent customer service standards.
      </p>
    </div>
  `;

  return {
    subject: `New Wedding Inquiry from ${inquiry.brideName} & ${inquiry.groomName}`,
    html,
    text: `New wedding inquiry from ${inquiry.brideName} & ${inquiry.groomName}. 
    Email: ${inquiry.email}, Phone: ${inquiry.phone}, 
    Wedding Date: ${inquiry.weddingDate || 'Not specified'}, 
    Guest Count: ${inquiry.guestCount || 'Not specified'}`
  };
}
