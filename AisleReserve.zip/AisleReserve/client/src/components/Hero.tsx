import { CalendarCheck, Images, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-fixed" 
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1519741497674-611481863552?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80')"
        }}
      />
      <div className="absolute inset-0 hero-gradient" />
      
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <div className="floating-animation">
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-primary-foreground mb-6 leading-tight">
            Where Love Stories<br />
            <span className="font-script text-accent">Become Legends</span>
          </h1>
          <p className="text-xl md:text-2xl text-primary-foreground/90 mb-8 font-light leading-relaxed">
            Create magical moments in our luxurious wedding halls, where every detail is crafted to perfection for your special day.
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button 
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 text-lg font-semibold shadow-lg transform hover:scale-105 transition-all"
            data-testid="button-book-tour"
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
          >
            <CalendarCheck className="mr-2" size={20} />
            Book a Tour
          </Button>
          <Button 
            variant="outline"
            className="bg-transparent border-2 border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-foreground px-8 py-4 text-lg font-semibold transform hover:scale-105 transition-all"
            data-testid="button-view-gallery"
            onClick={() => document.getElementById('gallery')?.scrollIntoView({ behavior: 'smooth' })}
          >
            <Images className="mr-2" size={20} />
            View Gallery
          </Button>
        </div>

        <div className="mt-12 flex justify-center items-center space-x-8 text-primary-foreground/80">
          <div className="text-center">
            <div className="text-3xl font-bold font-serif" data-testid="stat-celebrations">500+</div>
            <div className="text-sm">Celebrations</div>
          </div>
          <div className="w-px h-12 bg-primary-foreground/30" />
          <div className="text-center">
            <div className="text-3xl font-bold font-serif" data-testid="stat-experience">15+</div>
            <div className="text-sm">Years Experience</div>
          </div>
          <div className="w-px h-12 bg-primary-foreground/30" />
          <div className="text-center">
            <div className="text-3xl font-bold font-serif" data-testid="stat-capacity">1000</div>
            <div className="text-sm">Guest Capacity</div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-primary-foreground chevron-bounce">
        <ChevronDown size={32} />
      </div>
    </section>
  );
}
