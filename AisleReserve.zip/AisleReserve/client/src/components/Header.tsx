import { Crown, Phone, Menu } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-effect border-b border-border/20">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
              <Crown className="text-primary-foreground" size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-serif font-bold text-foreground">Elegance Manor</h1>
              <p className="text-xs text-muted-foreground font-script">Where Dreams Begin</p>
            </div>
          </div>
          
          <nav className="hidden lg:flex items-center space-x-8">
            <a href="#home" className="text-foreground hover:text-primary transition-colors font-medium" data-testid="nav-home">Home</a>
            <a href="#about" className="text-foreground hover:text-primary transition-colors font-medium" data-testid="nav-about">About</a>
            <a href="#venues" className="text-foreground hover:text-primary transition-colors font-medium" data-testid="nav-venues">Venues</a>
            <a href="#services" className="text-foreground hover:text-primary transition-colors font-medium" data-testid="nav-services">Services</a>
            <a href="#gallery" className="text-foreground hover:text-primary transition-colors font-medium" data-testid="nav-gallery">Gallery</a>
            <a href="#contact" className="text-foreground hover:text-primary transition-colors font-medium" data-testid="nav-contact">Contact</a>
          </nav>

          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center space-x-2 text-sm">
              <Phone className="text-primary" size={16} />
              <span className="text-foreground font-medium">+1 (555) 123-4567</span>
            </div>
            <button 
              className="lg:hidden text-foreground"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              data-testid="menu-toggle"
            >
              <Menu size={24} />
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden mt-4 pb-4 border-t border-border/20">
            <nav className="flex flex-col space-y-3 pt-4">
              <a href="#home" className="text-foreground hover:text-primary transition-colors font-medium" data-testid="mobile-nav-home">Home</a>
              <a href="#about" className="text-foreground hover:text-primary transition-colors font-medium" data-testid="mobile-nav-about">About</a>
              <a href="#venues" className="text-foreground hover:text-primary transition-colors font-medium" data-testid="mobile-nav-venues">Venues</a>
              <a href="#services" className="text-foreground hover:text-primary transition-colors font-medium" data-testid="mobile-nav-services">Services</a>
              <a href="#gallery" className="text-foreground hover:text-primary transition-colors font-medium" data-testid="mobile-nav-gallery">Gallery</a>
              <a href="#contact" className="text-foreground hover:text-primary transition-colors font-medium" data-testid="mobile-nav-contact">Contact</a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
