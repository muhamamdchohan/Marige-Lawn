import { testimonialsData } from "@/data/testimonials";
import { Star } from "lucide-react";

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 scroll-reveal">
          <span className="text-primary font-script text-2xl">Testimonials</span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mt-2 mb-6">
            Love Stories from Our Beautiful Couples
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Read what our couples have to say about their magical wedding day at Elegance Manor.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonialsData.map((testimonial) => (
            <div key={testimonial.id} className="scroll-reveal bg-card rounded-2xl p-8 border border-border shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-center mb-6">
                <div className="flex text-primary text-xl space-x-1 mr-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="fill-current" size={20} />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground" data-testid={`rating-${testimonial.id}`}>
                  {testimonial.rating}
                </span>
              </div>
              
              <p className="text-foreground italic mb-6 leading-relaxed" data-testid={`testimonial-text-${testimonial.id}`}>
                "{testimonial.text}"
              </p>
              
              <div className="flex items-center space-x-4">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.names}
                  className="w-16 h-16 rounded-full object-cover"
                  data-testid={`testimonial-image-${testimonial.id}`}
                />
                <div>
                  <h4 className="font-semibold text-foreground" data-testid={`testimonial-names-${testimonial.id}`}>
                    {testimonial.names}
                  </h4>
                  <p className="text-sm text-muted-foreground" data-testid={`testimonial-date-${testimonial.id}`}>
                    {testimonial.date}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 scroll-reveal">
          <div className="bg-muted/50 rounded-2xl p-8 text-center border border-border">
            <div className="flex justify-center items-center space-x-8 mb-6">
              <div className="text-center">
                <div className="text-4xl font-bold font-serif text-primary" data-testid="stat-average-rating">4.9</div>
                <div className="text-sm text-muted-foreground">Average Rating</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold font-serif text-primary" data-testid="stat-happy-couples">500+</div>
                <div className="text-sm text-muted-foreground">Happy Couples</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold font-serif text-primary" data-testid="stat-referral-rate">95%</div>
                <div className="text-sm text-muted-foreground">Referral Rate</div>
              </div>
            </div>
            <p className="text-muted-foreground">Based on verified reviews from couples who celebrated at Elegance Manor</p>
          </div>
        </div>
      </div>
    </section>
  );
}
