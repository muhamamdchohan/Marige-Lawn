import { Users, Star } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="scroll-reveal">
            <img 
              src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80" 
              alt="Our elegant wedding venue interior" 
              className="rounded-2xl shadow-2xl w-full"
              data-testid="img-venue-interior"
            />
          </div>
          
          <div className="scroll-reveal">
            <div className="mb-6">
              <span className="text-primary font-script text-2xl">Our Story</span>
              <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mt-2 mb-6">
                Creating Magical Moments Since 2008
              </h2>
            </div>
            
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              For over fifteen years, Elegance Manor has been the premier destination for couples seeking the perfect venue for their special day. Our passion for creating unforgettable experiences is matched only by our attention to the smallest details.
            </p>
            
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              Founded by the Johnson family with a vision to provide couples with a magical setting for their wedding celebrations, we've grown to become the most trusted name in luxury wedding venues.
            </p>

            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="text-center p-6 bg-card rounded-xl border border-border">
                <div className="text-3xl text-primary mb-2">
                  <Users className="mx-auto" size={48} />
                </div>
                <div className="text-2xl font-bold font-serif text-foreground" data-testid="text-max-capacity">1000</div>
                <div className="text-sm text-muted-foreground">Max Capacity</div>
              </div>
              <div className="text-center p-6 bg-card rounded-xl border border-border">
                <div className="text-3xl text-primary mb-2">
                  <Star className="mx-auto" size={48} />
                </div>
                <div className="text-2xl font-bold font-serif text-foreground" data-testid="text-rating">4.9</div>
                <div className="text-sm text-muted-foreground">Average Rating</div>
              </div>
            </div>

            <div className="flex items-start space-x-4 p-6 bg-accent/20 rounded-xl border border-accent">
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150" 
                alt="Michael Johnson, Venue Owner" 
                className="w-16 h-16 rounded-full object-cover"
                data-testid="img-owner"
              />
              <div>
                <p className="text-foreground italic mb-2">
                  "Every wedding is unique, and our commitment is to make your vision come to life with unparalleled elegance and service."
                </p>
                <p className="font-semibold text-foreground" data-testid="text-owner-name">Michael Johnson</p>
                <p className="text-sm text-muted-foreground">Founder & Owner</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
