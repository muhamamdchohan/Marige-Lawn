import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { MapPin, Phone, Mail, Clock, Send, Facebook, Instagram } from "lucide-react";

const contactSchema = z.object({
  brideName: z.string().min(1, "Bride's name is required"),
  groomName: z.string().min(1, "Groom's name is required"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(1, "Phone number is required"),
  weddingDate: z.string().optional(),
  guestCount: z.string().optional(),
  preferredVenue: z.string().optional(),
  services: z.string().optional(),
  message: z.string().optional(),
});

type ContactForm = z.infer<typeof contactSchema>;

export default function Contact() {
  const { toast } = useToast();
  const [selectedServices, setSelectedServices] = useState({
    catering: false,
    decoration: false,
    photography: false,
    planning: false,
  });

  const form = useForm<ContactForm>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      brideName: "",
      groomName: "",
      email: "",
      phone: "",
      weddingDate: "",
      guestCount: "",
      preferredVenue: "",
      services: "",
      message: "",
    },
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactForm) => {
      const payload = {
        ...data,
        services: JSON.stringify(selectedServices),
      };
      return apiRequest("POST", "/api/contact", payload);
    },
    onSuccess: () => {
      toast({
        title: "Inquiry Sent Successfully",
        description: "Thank you for your inquiry! We'll contact you within 24 hours.",
      });
      form.reset();
      setSelectedServices({
        catering: false,
        decoration: false,
        photography: false,
        planning: false,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Please check your form data and try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ContactForm) => {
    contactMutation.mutate(data);
  };

  const handleServiceChange = (service: string, checked: boolean) => {
    setSelectedServices(prev => ({
      ...prev,
      [service]: checked,
    }));
  };

  return (
    <section id="contact" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 scroll-reveal">
          <span className="text-primary font-script text-2xl">Contact Us</span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mt-2 mb-6">
            Let's Plan Your Perfect Day
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Ready to start planning your dream wedding? Get in touch with our team to schedule a tour and discuss your vision.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Information */}
          <div className="scroll-reveal">
            <div className="bg-card rounded-2xl p-8 border border-border shadow-lg">
              <h3 className="text-2xl font-serif font-bold text-foreground mb-6">Get in Touch</h3>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <MapPin className="text-primary" size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1">Address</h4>
                    <p className="text-muted-foreground" data-testid="text-address">123 Elegant Avenue<br />Wedding District, WD 12345</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Phone className="text-primary" size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1">Phone</h4>
                    <p className="text-muted-foreground" data-testid="text-phone">+1 (555) 123-4567</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Mail className="text-primary" size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1">Email</h4>
                    <p className="text-muted-foreground" data-testid="text-email">hello@elegancemanor.com</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Clock className="text-primary" size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1">Hours</h4>
                    <p className="text-muted-foreground" data-testid="text-hours">
                      Mon-Fri: 9AM - 6PM<br />
                      Sat-Sun: 10AM - 4PM
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-8 border-t border-border">
                <h4 className="font-semibold text-foreground mb-4">Follow Us</h4>
                <div className="flex space-x-4">
                  <a href="#" className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary hover:bg-primary hover:text-primary-foreground transition-all" data-testid="link-facebook">
                    <Facebook size={20} />
                  </a>
                  <a href="#" className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary hover:bg-primary hover:text-primary-foreground transition-all" data-testid="link-instagram">
                    <Instagram size={20} />
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Booking Form */}
          <div className="scroll-reveal">
            <div className="bg-card rounded-2xl p-8 border border-border shadow-lg">
              <h3 className="text-2xl font-serif font-bold text-foreground mb-6">Request a Quote</h3>
              
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="brideName">Bride's Name*</Label>
                    <Input
                      id="brideName"
                      {...form.register("brideName")}
                      placeholder="Enter bride's name"
                      data-testid="input-bride-name"
                    />
                    {form.formState.errors.brideName && (
                      <p className="text-destructive text-sm mt-1">{form.formState.errors.brideName.message}</p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="groomName">Groom's Name*</Label>
                    <Input
                      id="groomName"
                      {...form.register("groomName")}
                      placeholder="Enter groom's name"
                      data-testid="input-groom-name"
                    />
                    {form.formState.errors.groomName && (
                      <p className="text-destructive text-sm mt-1">{form.formState.errors.groomName.message}</p>
                    )}
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="email">Email*</Label>
                    <Input
                      id="email"
                      type="email"
                      {...form.register("email")}
                      placeholder="your@email.com"
                      data-testid="input-email"
                    />
                    {form.formState.errors.email && (
                      <p className="text-destructive text-sm mt-1">{form.formState.errors.email.message}</p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone*</Label>
                    <Input
                      id="phone"
                      type="tel"
                      {...form.register("phone")}
                      placeholder="(555) 123-4567"
                      data-testid="input-phone"
                    />
                    {form.formState.errors.phone && (
                      <p className="text-destructive text-sm mt-1">{form.formState.errors.phone.message}</p>
                    )}
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="weddingDate">Wedding Date</Label>
                    <Input
                      id="weddingDate"
                      type="date"
                      {...form.register("weddingDate")}
                      data-testid="input-wedding-date"
                    />
                  </div>
                  <div>
                    <Label htmlFor="guestCount">Guest Count</Label>
                    <Select onValueChange={(value) => form.setValue("guestCount", value)}>
                      <SelectTrigger data-testid="select-guest-count">
                        <SelectValue placeholder="Select guest count" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="50-100">50-100 guests</SelectItem>
                        <SelectItem value="100-200">100-200 guests</SelectItem>
                        <SelectItem value="200-300">200-300 guests</SelectItem>
                        <SelectItem value="300-500">300-500 guests</SelectItem>
                        <SelectItem value="500+">500+ guests</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="preferredVenue">Preferred Venue</Label>
                  <Select onValueChange={(value) => form.setValue("preferredVenue", value)}>
                    <SelectTrigger data-testid="select-preferred-venue">
                      <SelectValue placeholder="Select a venue" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="grand-ballroom">Grand Ballroom</SelectItem>
                      <SelectItem value="garden-pavilion">Garden Pavilion</SelectItem>
                      <SelectItem value="intimate-conservatory">Intimate Conservatory</SelectItem>
                      <SelectItem value="not-sure">Not sure yet</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Services Interested In</Label>
                  <div className="grid grid-cols-2 gap-3 mt-2">
                    {Object.entries(selectedServices).map(([service, checked]) => (
                      <div key={service} className="flex items-center space-x-2">
                        <Checkbox
                          id={service}
                          checked={checked}
                          onCheckedChange={(checked) => handleServiceChange(service, checked as boolean)}
                          data-testid={`checkbox-${service}`}
                        />
                        <Label htmlFor={service} className="text-sm capitalize">
                          {service}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="message">Special Requests or Questions</Label>
                  <Textarea
                    id="message"
                    {...form.register("message")}
                    rows={4}
                    placeholder="Tell us about your vision, dietary restrictions, special requirements, or any questions you have..."
                    className="resize-none"
                    data-testid="textarea-message"
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-primary text-primary-foreground py-4 text-lg font-semibold hover:bg-primary/90 transform hover:scale-[1.02] transition-all shadow-lg"
                  disabled={contactMutation.isPending}
                  data-testid="button-send-inquiry"
                >
                  <Send className="mr-2" size={20} />
                  {contactMutation.isPending ? "Sending..." : "Send Inquiry"}
                </Button>

                <p className="text-sm text-muted-foreground text-center">
                  We'll respond to your inquiry within 24 hours. For immediate assistance, please call us at{" "}
                  <a href="tel:+15551234567" className="text-primary hover:underline">
                    +1 (555) 123-4567
                  </a>
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
