import { Crown, MapPin, Phone, Mail, Facebook, Instagram } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-secondary text-secondary-foreground py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <Crown className="text-primary-foreground" size={20} />
              </div>
              <div>
                <h3 className="text-xl font-serif font-bold">Elegance Manor</h3>
                <p className="text-sm font-script opacity-90">Where Dreams Begin</p>
              </div>
            </div>
            <p className="text-secondary-foreground/80 mb-6">
              Creating magical wedding moments for over 15 years with unparalleled elegance and service.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-secondary-foreground/10 rounded-full flex items-center justify-center hover:bg-primary transition-colors" data-testid="footer-facebook">
                <Facebook size={20} />
              </a>
              <a href="#" className="w-10 h-10 bg-secondary-foreground/10 rounded-full flex items-center justify-center hover:bg-primary transition-colors" data-testid="footer-instagram">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#about" className="text-secondary-foreground/80 hover:text-primary transition-colors" data-testid="footer-about">About Us</a></li>
              <li><a href="#venues" className="text-secondary-foreground/80 hover:text-primary transition-colors" data-testid="footer-venues">Our Venues</a></li>
              <li><a href="#services" className="text-secondary-foreground/80 hover:text-primary transition-colors" data-testid="footer-services">Services</a></li>
              <li><a href="#gallery" className="text-secondary-foreground/80 hover:text-primary transition-colors" data-testid="footer-gallery">Gallery</a></li>
              <li><a href="#contact" className="text-secondary-foreground/80 hover:text-primary transition-colors" data-testid="footer-contact">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Services</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-secondary-foreground/80 hover:text-primary transition-colors" data-testid="footer-wedding-venues">Wedding Venues</a></li>
              <li><a href="#" className="text-secondary-foreground/80 hover:text-primary transition-colors" data-testid="footer-catering">Catering Services</a></li>
              <li><a href="#" className="text-secondary-foreground/80 hover:text-primary transition-colors" data-testid="footer-planning">Event Planning</a></li>
              <li><a href="#" className="text-secondary-foreground/80 hover:text-primary transition-colors" data-testid="footer-photography">Photography</a></li>
              <li><a href="#" className="text-secondary-foreground/80 hover:text-primary transition-colors" data-testid="footer-decoration">Decoration</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Contact Info</h4>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin className="text-primary mt-1" size={16} />
                <div>
                  <p className="text-secondary-foreground/80" data-testid="footer-address-1">123 Elegant Avenue</p>
                  <p className="text-secondary-foreground/80" data-testid="footer-address-2">Wedding District, WD 12345</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="text-primary" size={16} />
                <a href="tel:+15551234567" className="text-secondary-foreground/80 hover:text-primary transition-colors" data-testid="footer-phone">
                  +1 (555) 123-4567
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="text-primary" size={16} />
                <a href="mailto:hello@elegancemanor.com" className="text-secondary-foreground/80 hover:text-primary transition-colors" data-testid="footer-email">
                  hello@elegancemanor.com
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-secondary-foreground/20 pt-8 text-center">
          <p className="text-secondary-foreground/60">
            © 2024 Elegance Manor. All rights reserved. |{" "}
            <a href="#" className="hover:text-primary transition-colors" data-testid="footer-privacy">Privacy Policy</a> |{" "}
            <a href="#" className="hover:text-primary transition-colors" data-testid="footer-terms">Terms of Service</a>
          </p>
        </div>
      </div>
    </footer>
  );
}
