import { useState } from "react";
import { Button } from "@/components/ui/button";
import { galleryData, categories } from "@/data/gallery";
import { Images, Search } from "lucide-react";

export default function Gallery() {
  const [activeFilter, setActiveFilter] = useState('all');

  const filteredImages = activeFilter === 'all' 
    ? galleryData 
    : galleryData.filter(item => item.categories.includes(activeFilter));

  return (
    <section id="gallery" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 scroll-reveal">
          <span className="text-primary font-script text-2xl">Gallery</span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mt-2 mb-6">
            Dreams Captured in Time
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Browse through our collection of beautiful weddings and see how we've helped couples create their perfect day.
          </p>
        </div>

        {/* Gallery Filter Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12 scroll-reveal">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={activeFilter === category.id ? "default" : "outline"}
              className={`px-6 py-3 rounded-full font-medium transition-all ${
                activeFilter === category.id 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-card text-foreground border-border hover:bg-primary hover:text-primary-foreground"
              }`}
              onClick={() => setActiveFilter(category.id)}
              data-testid={`filter-${category.id}`}
            >
              {category.name}
            </Button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" id="gallery-grid">
          {filteredImages.map((image, index) => (
            <div 
              key={`${image.id}-${index}`}
              className="gallery-item scroll-reveal group cursor-pointer rounded-xl overflow-hidden relative"
              data-testid={`gallery-item-${image.id}`}
            >
              <img 
                src={image.src} 
                alt={image.alt}
                className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="gallery-overlay">
                <Search className="text-white" size={32} />
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12 scroll-reveal">
          <Button 
            className="bg-primary text-primary-foreground px-8 py-4 text-lg font-semibold hover:bg-primary/90 transform hover:scale-105 transition-all"
            data-testid="button-view-full-gallery"
          >
            <Images className="mr-2" size={20} />
            View Full Gallery
          </Button>
        </div>
      </div>
    </section>
  );
}
