import { Button } from "@/components/ui/button";
import { venuesData } from "@/data/venues";
import { Users, Expand, Leaf } from "lucide-react";

export default function Venues() {
  const getCapacityIcon = (capacity: string) => {
    if (capacity.includes("Outdoor")) return <Leaf size={16} />;
    return <Users size={16} />;
  };

  return (
    <section id="venues" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 scroll-reveal">
          <span className="text-primary font-script text-2xl">Our Venues</span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mt-2 mb-6">
            Exquisite Spaces for Every Celebration
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Choose from our collection of beautifully designed halls, each offering unique ambiance and features to match your wedding style.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {venuesData.map((venue, index) => (
            <div key={venue.id} className="scroll-reveal bg-card rounded-2xl shadow-lg overflow-hidden border border-border group hover:shadow-2xl transition-all duration-300">
              <img 
                src={venue.image} 
                alt={venue.alt}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                data-testid={`img-venue-${venue.id}`}
              />
              <div className="p-6">
                <h3 className="text-2xl font-serif font-bold text-foreground mb-2" data-testid={`text-venue-title-${venue.id}`}>
                  {venue.name}
                </h3>
                <p className="text-muted-foreground mb-4">
                  {venue.description}
                </p>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="flex items-center space-x-2">
                    {getCapacityIcon(venue.capacity)}
                    <span className="text-sm text-foreground" data-testid={`text-venue-capacity-${venue.id}`}>
                      {venue.capacity}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Expand size={16} className="text-primary" />
                    <span className="text-sm text-foreground" data-testid={`text-venue-size-${venue.id}`}>
                      {venue.size}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-primary" data-testid={`text-venue-price-${venue.id}`}>
                    {venue.price}
                  </span>
                  <Button 
                    className="bg-primary text-primary-foreground hover:bg-primary/90"
                    data-testid={`button-venue-details-${venue.id}`}
                  >
                    View Details
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
