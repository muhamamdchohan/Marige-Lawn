import { servicesData } from "@/data/services";
import { Button } from "@/components/ui/button";
import { Gift } from "lucide-react";

export default function Services() {
  return (
    <section id="services" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 scroll-reveal">
          <span className="text-primary font-script text-2xl">Our Services</span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mt-2 mb-6">
            Everything You Need for Your Perfect Day
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            From exquisite catering to stunning decorations, our comprehensive services ensure every detail is handled with perfection.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {servicesData.map((service, index) => (
            <div key={service.id} className="scroll-reveal text-center p-8 bg-card rounded-2xl border border-border hover:shadow-lg transition-all duration-300 group">
              <div className={`w-20 h-20 ${service.bgColor} rounded-full flex items-center justify-center mx-auto mb-6 ${service.hoverBg} transition-all duration-300`}>
                <service.icon className={`text-3xl ${service.iconColor} ${service.hoverIconColor} transition-all duration-300`} size={48} />
              </div>
              <h3 className="text-xl font-serif font-bold text-foreground mb-4" data-testid={`text-service-title-${service.id}`}>
                {service.title}
              </h3>
              <p className="text-muted-foreground mb-6">
                {service.description}
              </p>
              <ul className="text-sm text-muted-foreground space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} data-testid={`text-service-feature-${service.id}-${featureIndex}`}>
                    • {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 scroll-reveal">
          <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-8 md:p-12 text-center">
            <h3 className="text-3xl font-serif font-bold text-primary-foreground mb-4">
              Complete Wedding Packages Available
            </h3>
            <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
              Simplify your planning with our all-inclusive packages that combine venue, catering, decoration, and coordination services.
            </p>
            <Button 
              className="bg-primary-foreground text-primary px-8 py-4 text-lg font-semibold hover:bg-primary-foreground/90 transform hover:scale-105 transition-all"
              data-testid="button-view-packages"
            >
              <Gift className="mr-2" size={20} />
              View Package Options
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
