import { Utensils, Palette, Camera, ClipboardList } from "lucide-react";

export const servicesData = [
  {
    id: 'catering',
    icon: Utensils,
    title: 'Premium Catering',
    description: 'Gourmet cuisine crafted by our award-winning chefs with customizable menus for every taste.',
    features: [
      'Multi-course plated dinners',
      'Buffet and station options',
      'Dietary restrictions accommodated',
      'Premium bar service'
    ],
    bgColor: 'bg-primary/10',
    iconColor: 'text-primary',
    hoverBg: 'group-hover:bg-primary',
    hoverIconColor: 'group-hover:text-primary-foreground'
  },
  {
    id: 'decoration',
    icon: Palette,
    title: 'Event Decoration',
    description: 'Transform your vision into reality with our expert design team and premium décor options.',
    features: [
      'Custom floral arrangements',
      'Lighting design',
      'Linens and centerpieces',
      'Complete venue transformation'
    ],
    bgColor: 'bg-secondary/10',
    iconColor: 'text-secondary',
    hoverBg: 'group-hover:bg-secondary',
    hoverIconColor: 'group-hover:text-secondary-foreground'
  },
  {
    id: 'photography',
    icon: Camera,
    title: 'Photography & Video',
    description: 'Professional photography and videography partnerships to capture every precious moment.',
    features: [
      'Professional wedding photographers',
      'Cinematic videography',
      'Same-day editing available',
      'Drone footage options'
    ],
    bgColor: 'bg-accent/20',
    iconColor: 'text-accent-foreground',
    hoverBg: 'group-hover:bg-accent',
    hoverIconColor: 'group-hover:text-accent-foreground'
  },
  {
    id: 'planning',
    icon: ClipboardList,
    title: 'Wedding Planning',
    description: 'Dedicated wedding coordinators to manage every detail and ensure your day runs smoothly.',
    features: [
      'Full-service planning',
      'Day-of coordination',
      'Vendor management',
      'Timeline creation'
    ],
    bgColor: 'bg-primary/10',
    iconColor: 'text-primary',
    hoverBg: 'group-hover:bg-primary',
    hoverIconColor: 'group-hover:text-primary-foreground'
  }
];
