export const categories = [
  { id: 'all', name: 'All Photos' },
  { id: 'ceremonies', name: 'Ceremonies' },
  { id: 'receptions', name: 'Receptions' },
  { id: 'cuisine', name: 'Cuisine' },
  { id: 'decorations', name: 'Decorations' }
];

export const galleryData = [
  {
    id: 'ceremony-1',
    src: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    alt: 'Elegant wedding ceremony',
    categories: ['ceremonies']
  },
  {
    id: 'ceremony-2',
    src: 'https://images.unsplash.com/photo-1606216794074-735e91aa2c92?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    alt: 'Wedding aisle with decorations',
    categories: ['ceremonies', 'decorations']
  },
  {
    id: 'reception-1',
    src: 'https://images.unsplash.com/photo-1529636798458-92182e662485?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    alt: 'Reception hall setup',
    categories: ['receptions', 'decorations']
  },
  {
    id: 'reception-2',
    src: 'https://images.unsplash.com/photo-1520854221256-17451cc331bf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    alt: 'Wedding reception dancing',
    categories: ['receptions']
  },
  {
    id: 'cuisine-1',
    src: 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    alt: 'Wedding cake',
    categories: ['cuisine']
  },
  {
    id: 'cuisine-2',
    src: 'https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    alt: 'Wedding appetizers',
    categories: ['cuisine']
  },
  {
    id: 'decorations-1',
    src: 'https://images.unsplash.com/photo-1478146896981-b80fe463b330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    alt: 'Wedding floral centerpieces',
    categories: ['decorations']
  },
  {
    id: 'decorations-2',
    src: 'https://images.unsplash.com/photo-1465495976277-4387d4b0e4a6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    alt: 'Wedding ceremony arch',
    categories: ['decorations', 'ceremonies']
  }
];
