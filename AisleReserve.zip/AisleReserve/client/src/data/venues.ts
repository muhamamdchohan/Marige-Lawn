export const venuesData = [
  {
    id: 'grand-ballroom',
    name: 'Grand Ballroom',
    description: 'Our flagship venue featuring soaring ceilings, crystal chandeliers, and panoramic windows.',
    image: 'https://images.unsplash.com/photo-1464207687429-7505649dae38?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=600',
    alt: 'Grand Ballroom with crystal chandeliers',
    capacity: 'Up to 500 guests',
    size: '8,000 sq ft',
    price: '$8,500'
  },
  {
    id: 'garden-pavilion',
    name: 'Garden Pavilion',
    description: 'Enchanting outdoor venue surrounded by manicured gardens and natural beauty.',
    image: 'https://images.unsplash.com/photo-1469371670807-013ccf25f16a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=600',
    alt: 'Garden Pavilion outdoor ceremony venue',
    capacity: 'Up to 300 guests',
    size: 'Outdoor',
    price: '$6,200'
  },
  {
    id: 'intimate-conservatory',
    name: 'Intimate Conservatory',
    description: 'Perfect for smaller celebrations with glass walls overlooking our beautiful gardens.',
    image: 'https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=600',
    alt: 'Intimate Conservatory for small weddings',
    capacity: 'Up to 120 guests',
    size: '2,500 sq ft',
    price: '$3,800'
  }
];
