export const testimonialsData = [
  {
    id: 'testimonial-1',
    rating: '5.0',
    text: 'Elegance Manor exceeded all our expectations! The staff was incredible, the venue was breathtaking, and every detail was perfect. Our guests are still talking about how magical our wedding was.',
    names: 'Sarah & Michael',
    date: 'Married October 2023',
    image: 'https://images.unsplash.com/photo-1522673607200-164d1b6ce486?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150'
  },
  {
    id: 'testimonial-2',
    rating: '5.0',
    text: 'From the initial tour to our wedding day, the team at Elegance Manor made everything seamless. The Grand Ballroom was absolutely stunning, and the catering was exceptional. Highly recommend!',
    names: 'Emma & David',
    date: 'Married September 2023',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150'
  },
  {
    id: 'testimonial-3',
    rating: '5.0',
    text: 'The Garden Pavilion was the perfect setting for our outdoor ceremony. The attention to detail and customer service was outstanding. Our coordinator made sure everything ran smoothly!',
    names: 'Jessica & Ryan',
    date: 'Married August 2023',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150'
  }
];
