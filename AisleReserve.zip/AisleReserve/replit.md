# Elegance Manor - Premium Wedding Hall Website

## Overview
Elegance Manor is a luxury wedding hall website that showcases premium venues and services for couples planning their wedding celebrations. The application features an elegant, romantic design with comprehensive venue information, service details, photo galleries, testimonials, and a contact inquiry system. The site is designed to convert visitors into bookings through beautiful presentations and seamless user experience.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with custom wedding-themed color palette (gold, champagne, deep rose, blush pink)
- **UI Components**: Shadcn/ui component library for consistent, accessible design
- **Typography**: Custom font stack with Playfair Display (serif), Inter (sans-serif), and Dancing Script (cursive)
- **State Management**: React Query (TanStack Query) for server state and React Context for local state
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript for full-stack type safety
- **API Design**: RESTful endpoints with JSON responses
- **Data Storage**: In-memory storage with interface for future database integration
- **Email Service**: SendGrid integration for inquiry notifications
- **Session Management**: Express sessions with PostgreSQL store support
- **Error Handling**: Centralized error middleware with proper HTTP status codes

### Database Schema
- **Users Table**: ID, username, password for potential admin functionality
- **Inquiries Table**: Comprehensive wedding inquiry data including bride/groom names, contact info, wedding date, guest count, preferred venue, services, and messages
- **ORM**: Drizzle ORM configured for PostgreSQL with schema validation using Zod

### Contact and Inquiry System
- **Form Validation**: Multi-step contact form with comprehensive wedding-specific fields
- **Service Selection**: Checkbox-based service selection (catering, decoration, photography, planning)
- **Email Notifications**: Automated email sending to business owners when inquiries are submitted
- **Data Persistence**: All inquiries stored with timestamps for follow-up management

### Content Management
- **Static Data**: Venue information, services, testimonials, and gallery images managed through TypeScript data files
- **Image Handling**: External image sources (Unsplash) for high-quality wedding photography
- **SEO Optimization**: Proper meta tags, semantic HTML structure, and image alt attributes

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form, React Query for frontend functionality
- **UI Components**: Radix UI primitives for accessible component foundation
- **Styling**: Tailwind CSS, class-variance-authority, clsx for utility-first styling approach
- **Icons**: Lucide React for consistent iconography throughout the application

### Backend Services
- **Database**: Neon Database (PostgreSQL) with Drizzle ORM for data persistence
- **Email Service**: SendGrid for transactional email notifications
- **Session Storage**: connect-pg-simple for PostgreSQL-backed session management

### Development Tools
- **Build System**: Vite with React plugin for fast development and production builds
- **TypeScript**: Full-stack type safety with strict configuration
- **Replit Integration**: Cartographer and dev banner plugins for Replit-specific development features
- **Date Utilities**: date-fns for date formatting and manipulation

### Production Considerations
- **Environment Variables**: Database URL, SendGrid API key, contact emails configured via environment
- **Error Handling**: Runtime error overlay for development, graceful error handling in production
- **Asset Optimization**: Vite handles code splitting, tree shaking, and asset optimization automatically